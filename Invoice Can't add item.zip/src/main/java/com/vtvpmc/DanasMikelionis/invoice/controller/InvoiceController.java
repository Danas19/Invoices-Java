package com.vtvpmc.DanasMikelionis.invoice.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vtvpmc.DanasMikelionis.invoice.CreateInvoiceCommand;
import com.vtvpmc.DanasMikelionis.invoice.CreateItemCommand;
import com.vtvpmc.DanasMikelionis.invoice.model.Invoice;
import com.vtvpmc.DanasMikelionis.invoice.model.Item;
import com.vtvpmc.DanasMikelionis.invoice.repository.InvoiceRepository;
import com.vtvpmc.DanasMikelionis.invoice.repository.ItemRepository;
import com.vtvpmc.DanasMikelionis.invoice.service.InvoiceService;

@RestController
@RequestMapping(value="/api/invoice")
public class InvoiceController {
	@Autowired
	private InvoiceService service;
	
	
	
	@RequestMapping(path = "/{id}", method = RequestMethod.GET)
	public Invoice getInvoice(@PathVariable @Valid Long id) {
		return this.service.getInvoice(id);
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public Invoice addInvoice(@RequestBody @Valid CreateInvoiceCommand createInvoiceCommand) {
		return this.service.addInvoice(createInvoiceCommand);
	}
	
	@RequestMapping(value = "/item", method = RequestMethod.POST)
	public Item addItem(@RequestBody @Valid CreateItemCommand createItemCommand) {
		return this.service.addItem(createItemCommand);
	}
	
	
}
