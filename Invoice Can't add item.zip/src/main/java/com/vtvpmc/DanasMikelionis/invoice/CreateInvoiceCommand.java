package com.vtvpmc.DanasMikelionis.invoice;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

public class CreateInvoiceCommand {
	@NotNull
	@Length(min = 1, max = 20)
	private String number;
	
	@NotNull
	@Length(min = 10, max = 10)
	private String writingDate;
	
	@NotNull
	@Length(min = 1, max = 35)
	private String whatCompanyWrote;
	
	@NotNull
	@Length(min = 1, max = 35)
	private String reciever;
	
	public String getNumber() {
		return number;
	}
	
	public String getWritingDate() {
		return writingDate;
	}
	
	public String getWhatCompanyWrote() {
		return whatCompanyWrote;
	}
	
	public String getReciever() {
		return reciever;
	}
	
	
}
