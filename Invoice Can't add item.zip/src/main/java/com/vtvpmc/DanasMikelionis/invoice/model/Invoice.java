package com.vtvpmc.DanasMikelionis.invoice.model;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Invoice {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String number;
	private String writingDate;
	private String whatCompanyWrote;
	private String reciever;
	
	@OneToMany(mappedBy = "invoice")
	private Set<Item> items = new HashSet<>();
	
	public Collection<Item> getItems() {
		return this.items;
	}
	
	public void addItem(Item item) {
		this.items.add(item);
		item.setInvoice(this);
	}
	
	public Invoice() { }
	
	public Invoice(String number, String writingDate, String whatCompanyWrote, String reciever) {
		this.number = number;
		this.writingDate = writingDate;
		this.whatCompanyWrote = whatCompanyWrote;
		this.reciever = reciever;
	}
	
	public Long getId() {
		return id;
	}
	
	public String getNumber() {
		return number;
	}
	
	public String getWritingDate() {
		return writingDate;
	}
	
	public String getWhatCompanyWrote() {
		return whatCompanyWrote;
	}
	
	public String getReciever() {
		return reciever;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}
	
	public void setWritingDate(String writingDate) {
		this.writingDate = writingDate;
	}
	
	public void setWhatCompanyWrote(String whatCompanyWrote) {
		this.whatCompanyWrote = whatCompanyWrote;
	}
	
	public void setReciever(String reciever) {
		this.reciever = reciever;
	}
	
	
}
