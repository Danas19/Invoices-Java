package com.vtvpmc.DanasMikelionis.invoice.service;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vtvpmc.DanasMikelionis.invoice.CreateInvoiceCommand;
import com.vtvpmc.DanasMikelionis.invoice.CreateItemCommand;
import com.vtvpmc.DanasMikelionis.invoice.model.Invoice;
import com.vtvpmc.DanasMikelionis.invoice.model.Item;
import com.vtvpmc.DanasMikelionis.invoice.repository.InvoiceRepository;
import com.vtvpmc.DanasMikelionis.invoice.repository.ItemRepository;

@Service
public class InvoiceService {
	
	private InvoiceRepository invoiceRepository;
	
	@Autowired
	public InvoiceService(InvoiceRepository invoiceRepository, ItemRepository itemRepository) {
		super();
		this.invoiceRepository = invoiceRepository;
	}

	Logger log = Logger.getLogger(InvoiceService.class.getName());
	
	public Invoice getInvoice(Long id) {
		return this.invoiceRepository.findById(id).orElse(null);
	}
	
	public Invoice addInvoice(CreateInvoiceCommand createInvoiceCommand) {
		Invoice invoice = new Invoice(createInvoiceCommand.getNumber(),
				createInvoiceCommand.getWritingDate(),
					createInvoiceCommand.getWhatCompanyWrote(),
						createInvoiceCommand.getReciever());
		
		this.invoiceRepository.save(invoice);
		return invoice;
	}
	
	public Item addItem(CreateItemCommand createItemCommand) {
		if (this.getInvoice(createItemCommand.getInvoiceId()) == null) {
			return null;
		}
		Item item = new Item(createItemCommand.getName(), createItemCommand.getQuantity(),
				createItemCommand.getHeightCm(), createItemCommand.getWidthCm(),
					createItemCommand.getPriceEuroCents());
		log.info("\n\n\n\n\n" + item.toString());
		this.invoiceRepository.getOne(createItemCommand.getInvoiceId()).addItem(item);
		
		return item;
	}
}
